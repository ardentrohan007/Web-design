$(function(){
	$('.ultimate, .gift, .quality').hover(function(){
		var h = $(this).height(), w = $(this).width();
		$(this).find('.chocolate-hover').height(h).width(w).slideDown(800);
		$(this).find('.chocolate-hover img').height(h);
		$(this).find('.chocolate-hover p').width(w);
	}, function(){
		var h = $(this).height(), w = $(this).width();
		$(this).find('.chocolate-hover').slideUp(800);
		$(this).find('.chocolate-hover img').css('height', 'auto');
		$(this).find('.chocolate-hover p').width(w);
	});

	$('.navbar-collapse .navbar-right li').hover(function(){
		var w = $(this).width();
		$(this).find('.mask').slideDown(800);
		$(this).find('a').css('color', '#fff');
		$(this).find('.mask').width(w);
	}, function(){
		var w = $(this).width();
		$(this).find('.mask').slideUp(800);
		$(this).find('a').css('color', '#506a85');
		$(this).find('.mask').width(w);
	});
});